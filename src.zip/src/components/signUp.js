import React, { useEffect, useState } from "react";
import {
  Typography,
  Button,
  Box,
  Paper,
  Container,
  Grid,
  CardMedia,
  FormControl
} from "@mui/material";
import Newnavbar from "./NavBar";
import Footer from "./Footer";
import TextField from "@mui/material/TextField";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import XLRI_LOGO from "../images/xlri.png";
import Insaid_LOGO from "../images/white-logo (1).png";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import { Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress'
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
// import { useNavigate } from "react-router-dom";

export default function SignUp() {
    // let navigate = useNavigate();
  function clearConsole() {
    if (window.console || window.console.firebug) {
      console.clear();
    }
  }
  var md5=require('md5')
  var CryptoJS = require("crypto-js");
  let navigate = useNavigate();
//   const [user, setUser] = useState({ email: "", password: "",confirm_password:"" });
//   const handleChange = (e) => {
//     setUser({ ...user, [e.target.name]: e.target.value });
//   };

const[email,setEmail]=useState('')
const[password,setPassword]=useState('')
const[confirmPassword,setComfirm]=useState('')
const[firstname,setFirstName]=useState('')
const[lastname,setLastName]=useState('')
const[middlename,setMiddleName]=useState('')
const[btn,setBtn]=useState(true)
const [course, setCourse] = useState([]);
const [courses, setCourses] = useState(" ");
const [category, setCategory] = useState(" ");
const [coursescode, setCoursescode] = useState(" ");
const [backopen, setBackopen] = useState(false);
const handleChangecourse = (pcode, pid,cid) => {
  setCourses(pid);
  setCoursescode(pcode);
  setCategory(cid);

  console.log(pid);
};
  const LoaderClose = () => {
    setBackopen(false);
  };
  const LoaderOpen = () => {
    setBackopen(true);
  };

const handleChangeEmail=(e)=>{
    setEmail(e.target.value)
}
const handleChangeFirstName=(e)=>{
  setFirstName(e.target.value)
}
const handleChangeLastName=(e)=>{
  setLastName(e.target.value)
}
const handleChangeMiddleName=(e)=>{
  setMiddleName(e.target.value)
}
const handleChangePassword=(e)=>{
    setPassword(e.target.value)
}
const handleChangeComfirm=(e)=>{
    setComfirm(e.target.value)
}


console.log(middlename+" "+lastname,"lll")

const handleSubmit=(e)=>{
    LoaderOpen();
e.preventDefault();
    if(email&&firstname&&lastname){
        // if(password===confirmPassword){
            console.log("yyyyyyyyyyyyyyyyy")
            // const sendData = {
            //     type: 'xlri_sign_up',

            //     username:email,
            //     password:password
               
            //   };
            // https://insaid.co/xlri-backend/shubham-data.php
              axios({
                method: 'post',
                url: 'https://insaid.co/xlri-backend/wpdata.php',
                data: {
                    type: 'xlri_sign_up',
                    username: email,
                    firstname:firstname,
                    middlename:middlename,
                    lastname:lastname,
                    program_id:courses,
                    // password: password,
                  }
              })
                .then(function (response) {
                    LoaderClose();
                    if(response.data.status==200){
                        toast.success("Your account has been created successfully", {
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                            theme: "colored",
                          });
                          setEmail('');
                          setPassword('');
                          setComfirm('');
                          setTimeout(()=>{
                            navigate("/login")
                          },2000)
                    }
                    else{
                      toast.error("Please try again. If you already have an account, please try login.",{
                        position: "top-right",
                        autoClose: 4000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "colored",
                      });
                      
                    }
                });
                
        // }
        // else{
        //   LoaderClose()
        //     toast.error(" Password are not matched", {
        //         position: "top-right",
        //         autoClose: 2000,
        //         hideProgressBar: false,
        //         closeOnClick: true,
        //         pauseOnHover: true,
        //         draggable: true,
        //         progress: undefined,
        //         theme: "colored",
        //       });
             
              
        // }
    }
    else{
      LoaderClose()
        toast.error("Please enter all the required fields", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });
    }
}
const BootstrapInput = styled(InputBase)(({ theme }) => ({
    'label + &': {
      marginTop: theme.spacing(3),
    },
    '& .MuiInputBase-input': {
      borderRadius: 4,
      position: 'relative',
      backgroundColor: theme.palette.mode === 'light' ? '#fcfcfb' : '#2b2b2b',
      border: '1px solid #ced4da',
      fontSize: 16,
      width: 250,
      padding: '10px 12px',
      transition: theme.transitions.create([
        'border-color',
        'background-color',
        'box-shadow',
      ]),
      // Use the system font instead of the default Roboto font.
      fontFamily: [
        '-apple-system',
        'BlinkMacSystemFont',
        '"Segoe UI"',
        'Roboto',
        '"Helvetica Neue"',
        'Arial',
        'sans-serif',
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
      ].join(','),
      '&:focus': {
        boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
        borderColor: theme.palette.primary.main,
      },
    },
  }));  
  useEffect(() => {
    fathcprogram();
  
  }, []);
  function fathcprogram() {
    axios({
      method: "post",
      url: "https://insaid.co/xlri-backend/data.php",
      data: {
        type: "fetch_xlri_programs",
        
      },
    }).then(function (response) {
    console.log(response);
    setCourse(response.data);
    });
  }
  return (
    <>
      {/* <Newnavbar/> */}
      <Box
        sx={{ mb: 1, mt: 1, justifyContent: "space-between",display:{xs:"none",lg:"flex"} }}
      >
        {/* <Typography sx={{color:"#fff",fontSize:"30px"}}>
           
            </Typography> */}
        <CardMedia
          fullWidth
          component="img"
          image={XLRI_LOGO}
          alt="green iguana"
          sx={{
            display: { xs: "none", lg: "block" },
            //  objectFit:"none",
            width: 130,
            py: 1,
            mt: 1,
            ml: 1,
          }}
        />
        <CardMedia
          fullWidth
          component="img"
          image={Insaid_LOGO}
          alt="green iguana"
          sx={{
            display: { xs: "none", lg: "block" },
            objectFit: "none",
            width: 160,
            py: 1,
            mt: 1,
            mr: 1,
            ml: 1,
          }}
        />
      </Box>
      <Box
        sx={{ mb: 1,  justifyContent: "space-between",display:{xs:"flex",lg:"none"},
      // background:"radial-gradient(circle at 50% 0, rgba(0, 0, 0, 0), #000000 100%)"
      
      }}
      >
        {/* <Typography sx={{color:"#fff",fontSize:"30px"}}>
           
            </Typography> */}
        <CardMedia
          fullWidth
          component="img"
          image={XLRI_LOGO}
          alt="green iguana"
          sx={{
            
            width: 110,
            py: 1,
            mt: 1,
            ml: 1,
          }}
        />
        <CardMedia
          fullWidth
          component="img"
          image={Insaid_LOGO}
          alt="green iguana"
          sx={{
            objectFit: "none",
            width: 163,
            py: 1,
            mt: 1,
            mr: 1,
            ml: 1,
          }}
        />
      </Box>
      <Box sx={{ pt: 0.5 }}>
        <Container fixed>
          <Box>
            <Box sx={{ my: "auto" }}>
              <Grid container spacing={6} justifyContent="center">
                <Grid item lg={6} sx={{ pb: 4 }}>
                  <Paper
                    elevation={3}
                    sx={{
                      boxShadow: "0 0 1rem 0 rgba(0, 0, 0, .2)",
                      borderRadius: "15px",
                      backgroundColor: "rgba(255, 255, 255, .15)",

                      backdropFilter: "blur(5px)",
                      border: "1px solid #fdb714",
                      p: 3,
                    }}
                  >
                    <Box>
                      <Typography
                        sx={{
                          textAlign: "center",
                          py: 1,
                          fontWeight: "bold",
                          color: "#fff",
                          fontSize: "20px",
                        }}
                      >
                        Sign Up
                      </Typography>
                    </Box>
                    <Box sx={{ mx: 2, py: 1 }}>
                      <form onSubmit={handleSubmit} >
                        <Box sx={{mt:1}}>
                        <Box sx={{display:"flex",justifyContent:"space-between"}}>
                        <Box>
                        <Typography
                          sx={{
                            fontWeight: "bold",
                            fontSize: "14px",
                            color: "#ffffff",
                          }}
                        >
                        First Name<span style={{ color: "red" }}>*</span>
                        </Typography>
                        <TextField onChange={handleChangeFirstName} fullWidth sx={{mb:2,background:"#fff",borderRadius:"4px"}} size="small"
                         onKeyPress={(e) => {
                          if (new RegExp(/[a-zA-Z]/).test(e.key)) {
                          } else e.preventDefault();
                        }}
                        />
                       
                        </Box>
                        <Box>
                        <Typography
                          sx={{
                            fontWeight: "bold",
                            fontSize: "14px",
                            color: "#ffffff",
                          }}
                        >
                        Middle Name
                        </Typography>
                        <TextField onChange={handleChangeMiddleName} fullWidth sx={{mb:2,background:"#fff",borderRadius:"4px"}} size="small"
                         onKeyPress={(e) => {
                          if (new RegExp(/[a-zA-Z]/).test(e.key)) {
                          } else e.preventDefault();
                        }}
                        />
                       
                        </Box>
                        </Box>
                        


                        <Box sx={{display:"flex",justifyContent:"space-between"}}>
                        <Box>
                          <Typography
                          sx={{
                            fontWeight: "bold",
                            fontSize: "14px",
                            color: "#ffffff",
                          }}
                        >
                        Last Name<span style={{ color: "red" }}>*</span>
                        </Typography>
                        <TextField onChange={handleChangeLastName}  fullWidth sx={{mb:2,background:"#fff",borderRadius:"4px"}} size="small"
                        
                        onKeyPress={(e) => {
                          if (new RegExp(/[a-zA-Z]/).test(e.key)) {
                          } else e.preventDefault();
                        }}
                        />
                       
                          </Box>
                          <Box>
                       <Typography
                          sx={{
                            fontWeight: "bold",
                            fontSize: "14px",
                            color: "#ffffff",
                          }}
                        >
                          Email<span style={{ color: "red" }}>*</span>
                        </Typography>
                        <TextField onChange={handleChangeEmail} type="email" fullWidth sx={{mb:2,background:"#fff",borderRadius:"4px"}} size="small"/>
                       
                       </Box>
                        </Box>
                          
                        </Box>
                      <Box sx={{mb:3}} >
                      <Box>
                       <Typography
                          sx={{
                            fontWeight: "bold",
                            fontSize: "14px",
                            color: "#ffffff",
                          }}
                        >
                          Program <span style={{ color: "red" }}>*</span>
                        </Typography>
                        <FormControl fullWidth>
                <Select
                  size="small"
                  sx={{ width: 470, background: "#fff" }}
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={country}
                  defaultValue="38"
                  label="course"
                  // onChange={handleChangeCountry}
                >
                  
                  {course.map((val, i) => (
                    <MenuItem  onClick={() => handleChangecourse(val.pcode, val.pid,val.category_id)} value={val.pid}>{val.pname}</MenuItem>
                   ))}
                </Select>
              </FormControl>
                       
                       </Box>
                      <Box>

                       

                      {/* <Typography
                          sx={{
                            fontWeight: "bold",
                            fontSize: "14px",
                            color: "#ffffff",
                          }}
                        >
                          Password <span style={{ color: "red" }}>*</span>
                        </Typography>
                        <TextField onChange={handleChangePassword} type="password" fullWidth sx={{mb:2,background:"#fff",borderRadius:"4px"}} size="small"/>
                        */}
                      </Box>
                       
                      </Box>
                          <Box sx={{mt:1,mb:1}}>
                          <Box>
                      {/* <Typography
                          sx={{
                            fontWeight: "bold",
                            fontSize: "14px",
                            color: "#ffffff",
                          }}
                        >
                          {" "}
                          Confirm Password{" "}
                          <span style={{ color: "red" }}>*</span>
                        </Typography>
                        <TextField onChange={handleChangeComfirm}  type="password" fullWidth sx={{mb:2,background:"#fff",borderRadius:"4px"}} size="small"/>
                        */}
                      </Box>
                          </Box>
                      
                       
                       
                        <Button sx={{background:"#fdb714",color:"#fff","&:hover":{background:"#fdb714",color:"#fff"}}}  variant="contained" fullWidth type="submit">
                          Sign Up
                        </Button>
                      </form>
                      <Box sx={{ display: "flex",justifyContent:"center",alignItems:"center" }}>
                        <Typography sx={{ py: 1, color: "#fff" }}>
                          Already a user?
                        </Typography>
                        <Link
                          style={{
                            marginTop: "-5px",
                            marginLeft: "10px",
                            color: "#fff",
                          }}
                          to="/login"
                        >
                          Login
                        </Link>
                      </Box>
                    </Box>
                  </Paper>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Container>
      </Box>
      <Backdrop
                    sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={backopen}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
      <ToastContainer/>
      {/* <Footer/> */}
    </>
  );
}
