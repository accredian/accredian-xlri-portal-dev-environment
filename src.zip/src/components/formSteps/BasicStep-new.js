import React, { useEffect, useState } from "react";
import {
  Typography,
  Button,
  Box,
  Paper,
  Grid,
  TextField,
  FormControlLabel,
  Badge,
  Checkbox,
  Tabs,
  Tab,
  Step,
  CardMedia,
} from "@mui/material";
import axios from "axios";
import Stepper from "@mui/material/Stepper";
import StepLabel from "@mui/material/StepLabel";
import Collapse from "@mui/material/Collapse";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import StepButton from "@mui/material/StepButton";
import Personal from "./Personal";
import PersonalNew from "./PersonalNew";
import PaymentNew from "./FeePayment-new";
import Payment from "./FeePayment";
import AdmissionNew from "./AddmissionFee-new";
import Education from "./Education";
import XLRI_LOGO from "../../images/xlri.png";
import Insaid_LOGO from "../../images/white-logo (1).png";
import LogoutIcon from "@mui/icons-material/Logout";
import { Link, useNavigate } from "react-router-dom";
import PreviewForm from "./FormPreview";
import { createTheme, ThemeProvider } from "@mui/material/styles";
// import { styled } from '@mui/material/styles';
import { makeStyles } from "@mui/styles";
import { styled } from "@mui/material/styles";
import Check from "@mui/icons-material/Check";

const ColorlibStepIconRoot = styled("div")(({ theme, ownerState }) => ({
  backgroundColor:
    theme.palette.mode === "dark" ? theme.palette.grey[700] : "#ccc",
  zIndex: 1,
  color: "#fff",
  width: 50,
  height: 50,
  // fontSize:"100px",
  display: "flex",
  borderRadius: "50%",
  justifyContent: "center",
  alignItems: "center",
  ...(ownerState.active && {
    backgroundColor: "#fdb714",
  }),
  ...(ownerState.completed && {
    backgroundColor: "green",
  }),
}));


function ColorlibStepIcon(props) {
  const { active, completed, className } = props;

  const icons = {
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
  };

  return (
    <ColorlibStepIconRoot
      ownerState={{ completed, active }}
      className={className}
    >
      {completed ? (
        <Check sx={{ fontSize: "35px" }} />
      ) : (
        <Box>
          {active ? (
            <Typography sx={{ fontSize: "20px", fontWeight: "bold" }}>
              {icons[String(props.icon)]}
            </Typography>
          ) : (
            <Typography sx={{ fontSize: "20px" }}>
              {icons[String(props.icon)]}
            </Typography>
          )}
        </Box>
      )}
    </ColorlibStepIconRoot>
  );
}

// Mobile Version
const ColorlibStepIconRootMob = styled("div")(({ theme, ownerState }) => ({
  backgroundColor:
    theme.palette.mode === "dark" ? theme.palette.grey[700] : "#ccc",
  zIndex: 1,
  color: "#fff",
  width: 25,
  height: 25,
  // fontSize:"100px",
  display: "flex",
  borderRadius: "50%",
  justifyContent: "center",
  alignItems: "center",
  ...(ownerState.active && {
    backgroundColor: "#fdb714",
  }),
  ...(ownerState.completed && {
    backgroundColor: "green",
  }),
}));


function ColorlibStepIconMob(props) {
  const { active, completed, className } = props;

  const icons = {
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
  };

  return (
    <ColorlibStepIconRootMob
      ownerState={{ completed, active }}
      className={className}
    >
      {completed ? (
        <Check sx={{ fontSize: "17px" }} />
      ) : (
        <Box>
          {active ? (
            <Typography sx={{ fontSize: "12px", fontWeight: "bold" }}>
              {icons[String(props.icon)]}
            </Typography>
          ) : (
            <Typography sx={{ fontSize: "12px" }}>
              {icons[String(props.icon)]}
            </Typography>
          )}
        </Box>
      )}
    </ColorlibStepIconRootMob>
  );
}


const BasicNew = () => {
  // const classes = useStyles();
  let navigate = useNavigate();
  const [user, setUser] = useState("");
  useEffect(() => {
    var user_id = localStorage.getItem("user_id");
    setUser(user_id);
  }, []);

  if (user == null) {
    navigate(`/Login`);
  }
  let [activeStep, setActiveStep] = useState(0);
  const [nxt, setNxt] = useState(true);
  const [step, setSteps] = useState("");
  const [completed, setCompleted] = useState({});
  // const[firstname,setfirstname]=useState('')
  // const[lastname,setLastName]=useState('')
  // const[stepState,setStepstate]=useState('')

  function stepCount() {
    axios({
      method: "post",
      url: "https://insaid.co/xlri-backend/data.php",
      data: {
        type: "xlri_step",
        user_id: localStorage.getItem("user_id"),
      },
    }).then(function (response) {
      console.log(response.data[0], "step");
      setSteps(response.data[0]);
    });
  }
  function userd() {
    axios({
      method: "post",
      url: "https://insaid.co/xlri-backend/data.php",
      data: {
        type: "get_user_basic_details",
        user_id: localStorage.getItem("user_id"),
      },
    }).then(function (response) {
      // console.log(response.data,"user")
      // setfirstname(response.data.firstname)
      // setLastName(response.data.lastname)
      localStorage.setItem("firstname", response.data.firstname);
      if(response.data.lastname.split(" ").length>1){
        localStorage.setItem("lastname", response.data.lastname.split(" ")[1]);
        localStorage.setItem("middlename", response.data.lastname.split(" ")[0]);
      }
      else{
        localStorage.setItem("lastname", response.data.lastname);
      }
    });
  }
  useEffect(() => {
    stepCount();
    userd();
  }, []);
  console.log(step, "step ka ibject");
  useEffect(() => {
    if (step) {
      console.log("inside step");
      if (step.stepone == "pending") {
        setActiveStep(0);
        _renderStepContent(0);
      }
      if (
        (step.steptwo == "pending" || step.steptwo == "inprocess") &&
        step.stepone == "complete"
      ) {
        setActiveStep(1);
        const newCompleted = completed;
        newCompleted[0] = true;
        setCompleted(newCompleted);
        _renderStepContent(1);
      }
      if (
        (step.stepthree == "pending" || step.stepthree == "inprocess") &&
        step.steptwo == "complete"
      ) {
        setActiveStep(2);
        const newCompleted = completed;
        newCompleted[0] = true;
        newCompleted[1] = true;
        setCompleted(newCompleted);
        _renderStepContent(2);
      }
      if (
        (step.stepfour == "pending" || step.stepfour == "inprocess") &&
        step.stepthree == "complete"
      ) {
        setActiveStep(3);
        const newCompleted = completed;
        newCompleted[0] = true;
        newCompleted[1] = true;
        newCompleted[2] = true;
        setCompleted(newCompleted);
        _renderStepContent(3);
      }
      if (
        (step.steplast == "pending" || step.steplast == "inprocess") &&
        step.stepfour == "complete"
      ) {
        setActiveStep(4);
        const newCompleted = completed;
        newCompleted[0] = true;
        newCompleted[1] = true;
        newCompleted[2] = true;
        newCompleted[3] = true;
        setCompleted(newCompleted);
        _renderStepContent(4);
      }
      if (
        step.stepone == "complete" &&
        step.steptwo == "complete" &&
        step.stepthree == "complete" &&
        step.steplast == "complete"
      ) {
        setActiveStep(4);
        const newCompleted = completed;
        newCompleted[0] = true;
        newCompleted[1] = true;
        newCompleted[2] = true;
        newCompleted[3] = true;
        setCompleted(newCompleted);
        _renderStepContent(4);
      }
    }
  }, [activeStep, step]);
  // console.log(activeStep,"step count")
  function _renderStepContent(steps) {
    switch (steps) {
      case 0:
        return (
          <PersonalNew
            setNxt={setNxt}
            handleNext1={handleNext1}
            stepCount={stepCount}
            userd={userd}
            step={step}
            // firstname={firstname}
            // lastname={lastname}
          />
        );
      case 1:
        return (
          <PaymentNew
            step={step}
            userd={userd}
            stepCount={stepCount}
            handleNext2={handleNext2}
          />
        );
      case 2:
        return (
          <AdmissionNew
            step={step}
            stepCount={stepCount}
            userd={userd}
            handleNext3={handleNext3}
          />
        );
      case 3:
        return (
          <Education
            step={step}
            stepCount={stepCount}
            userd={userd}
            handleNext4={handleNext4}
          />
        );
      case 4:
        return <PreviewForm step={step} />;
      default:
        return <div>Not Found</div>;
    }
  }

  const steps = [
    "Basic Details",
    "Application Fee Payment",
    "Admission Fee Payment",
    "Education and Work",
    "Admission Form Preview",
  ];

  const totalSteps = () => {
    return steps.length;
  };

  const completedSteps = () => {
    return Object.keys(completed).length;
  };

  const isLastStep = () => {
    return activeStep === totalSteps() - 1;
  };

  const allStepsCompleted = () => {
    return completedSteps() === totalSteps();
  };

  const handleNext1 = () => {
    // activeStep++;
    setActiveStep(1);
    const newCompleted = completed;
    newCompleted[0] = true;
    setCompleted(newCompleted);
    _renderStepContent(1);
  };
  const handleNext2 = () => {
    // activeStep++;
    setActiveStep(2);
    const newCompleted = completed;
    newCompleted[0] = true;
    newCompleted[1] = true;
    setCompleted(newCompleted);
    _renderStepContent(2);
  };
  const handleNext3 = () => {
    // activeStep++;
    setActiveStep(3);
    const newCompleted = completed;
    newCompleted[0] = true;
    newCompleted[1] = true;
    newCompleted[2] = true;
    setCompleted(newCompleted);
    _renderStepContent(3);
  };
  const handleNext4 = () => {
    // activeStep++;
    setActiveStep(4);
    const newCompleted = completed;
    newCompleted[0] = true;
    newCompleted[1] = true;
    newCompleted[2] = true;
    newCompleted[3] = true;
    setCompleted(newCompleted);
    _renderStepContent(4);
  };

  const handleLogout = () => {
    localStorage.removeItem("user_id");
    localStorage.removeItem("email");
    localStorage.clear();
    navigate("/login");
  };
  const handleStep = (step) => () => {
    setActiveStep(step);
  };

  //   const handleComplete = () => {

  //   };

  const handleReset = () => {
    setActiveStep(0);
    setCompleted({});
  };
  return (
    <>
      <Box className="bg">
        <Box sx={{ mb: 3, display: "flex" }}>
          <Box>
            <CardMedia
              fullWidth
              component="img"
              image={XLRI_LOGO}
              alt="green iguana"
              sx={{
                display: { xs: "none", lg: "block" },
                //  objectFit:"none",
                width: 130,
                py: 1,
                mt: 1,
                ml: 1,
              }}
            />
            <CardMedia
              fullWidth
              component="img"
              image={XLRI_LOGO}
              alt="green iguana"
              sx={{
                display: { xs: "block", lg: "none" },
                //  objectFit:"none",
                width: 110,
                py: 1,
                mt: 1,
                ml: 1,
              }}
            />
          </Box>

          <Box sx={{ display: "flex", justifyContent: "end", width: "82%" }}>
            <CardMedia
              fullWidth
              component="img"
              image={Insaid_LOGO}
              alt="green iguana"
              sx={{
                display: { xs: "none", lg: "block" },
                objectFit: "none",
                width: 160,
                py: 1,
                // mt:1,
               
                ml: 6,
              }}
            />
            {/* <Box sx={{font}}> */}
            <CardMedia
              fullWidth
              component="img"
              image={Insaid_LOGO}
              alt="green iguana"
              sx={{
                display: { xs: "block", lg: "none" },
                objectFit: "none",
                width: 145,
                // fontSize:"2px",
                py: 1,
               
                // mt:1,
                mr: 1,
                ml: 1,
              }}
            />
            {/* </Box> */}
           
          </Box>

          <Box sx={{ mt: 3.8,ml:2,display: { xs: "none", lg: "block" } }}>
            <LogoutIcon
              sx={{ color: "#fff", cursor: "pointer" }}
              onClick={handleLogout}
            />
          </Box>
          <Box sx={{ mt: 3.2,mr:1,display: { xs: "block", lg: "none" } }}>
            <LogoutIcon
              sx={{ color: "#fff", cursor: "pointer",fontSize:"1.2rem" }}
              onClick={handleLogout}
            />
          </Box>
        </Box>
        <Box
          sx={{
            boxShadow: "0 0 1rem 0 rgba(0, 0, 0, .2)",
            borderRadius: "15px",
            backgroundColor: "rgba(255, 255, 255, .30)",
            backdropFilter: "blur(5px)",
            border: "1px solid #fdb714",
            p: 3,
            mx: 4,
            height: 425,
          }}
        >
        {/* desktop version of stepper  */}
          <Box
            sx={{
              width: "80%",
              mb: 2,
              marginLeft: "auto",
              marginRight: "auto",
              display: { xs: "none", lg: "block" }
            }}
          >
           

            <Stepper
              nonLinear
              activeStep={activeStep}
              alternativeLabel
              connector={false}
            >
              {steps.map((label, index) => (
                <Step key={label} completed={completed[index]}>
                  <StepLabel StepIconComponent={ColorlibStepIcon}>
                    <Typography
                      sx={{
                        color: "#fff",
                        fontSize: "1rem",
                        fontWeight: "bold",
                      }}
                    >
                      {label}
                    </Typography>
                  </StepLabel>
                </Step>
              ))}
            </Stepper>
            

            <div>
              {allStepsCompleted() ? (
                <React.Fragment></React.Fragment>
              ) : (
                <React.Fragment></React.Fragment>
              )}
            </div>
          </Box>
          {/* Mobile version of stepper */}
          <Box
            sx={{
              width: "100%",
              mb: 2,
              marginLeft: "auto",
              marginRight: "auto",
              display: { xs: "block", lg: "none" }
            }}
          >
            

            <Stepper
              nonLinear
              activeStep={activeStep}
              alternativeLabel
              connector={false}
            >
              {steps.map((label, index) => (
                <Step key={label} completed={completed[index]}>
                  <StepLabel StepIconComponent={ColorlibStepIconMob}>
                    <Typography
                      sx={{
                        color: "#fff",
                        fontSize: "0.5rem",
                        fontWeight: "bold",
                      }}
                    >
                      {label}
                    </Typography>
                  </StepLabel>
                </Step>
              ))}
            </Stepper>
           

            <div>
              {allStepsCompleted() ? (
                <React.Fragment></React.Fragment>
              ) : (
                <React.Fragment></React.Fragment>
              )}
            </div>
          </Box>

        {/* Desktop version */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Box
              sx={{
                p: 3,
                width: "85%",
                borderRadius: "15px",

                overflowY: "scroll",
                height: 270,
                "&::-webkit-scrollbar": {
                  width: "0.2em",
                },
                "&::-webkit-scrollbar-track": {
                  boxShadow: "inset 0 0 6px silver",
                  webkitBoxShadow: "inset 0 0 6px silver",
                },
                "&::-webkit-scrollbar-thumb": {
                  backgroundColor: "silver",
                  outline: "1px solid silver",
                },
              }}
            >
              {_renderStepContent(activeStep)}
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};
export default BasicNew;
