import React, { useEffect, useState } from "react";
import {
  Typography,
  Button,
  Box,
  Paper,
  Grid,
  TextField,
  FormControlLabel,
  Link,
  Badge,
  Checkbox,
  Tabs,
  Tab,
  Step,
} from "@mui/material";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";

import Collapse from "@mui/material/Collapse";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import axios from "axios";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import useRazorpay from "react-razorpay";
import { useNavigate } from "react-router-dom";
import LinearProgress, {
  linearProgressClasses,
} from "@mui/material/LinearProgress";

import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";

const BootstrapInput = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#d9d9d9" : "#2b2b2b",
    border: "1px solid #d9d9d9",
    fontSize: 16,
    width: 480,
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));
const BorderLinearProgress = styled(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#fdb714" : "#fdb714",
  },
}));

const PaymentNew = (props) => {
  console.log(props.step, "step 2");
  let navigate = useNavigate();
  const [user, setUser] = useState("");
  useEffect(() => {
    var user_id = localStorage.getItem("user_id");
    setUser(user_id);
  }, []);

  if (user == null) {
    navigate(`/Login`);
  }

  const [openPersonal, setOpenPersonal] = useState(false);
  const [openADD, setOpenADD] = useState(false);
  const [openaddress, setOpenaddress] = useState(false);
  const [course, setCourse] = useState([]);
  // const [batch, setBatch] = useState([]);
  const [paymentid, setPaymentid] = useState("");
  const [backopen, setBackopen] = useState(false);
  const [batch, setBatch] = useState([]);
  const [batchs, setBatchs] = useState(" ");
  const [batchtext, setBatchtxt] = useState(" ");
  const [courses, setCourses] = useState(" ");
  const [category, setCategory] = useState(" ");
  const [coursescode, setCoursescode] = useState(" ");
  const LoaderClose = () => {
    setBackopen(false);
  };
  const LoaderOpen = () => {
    setBackopen(true);
  };
  const handleClickPersonal = () => {
    setOpenPersonal(!openPersonal);
  };
  const handleClickAdd = () => {
    setOpenADD(!openADD);
  };
  const handleClickaddress = () => {
    setOpenaddress(!openaddress);
  };
  function userd() {
    axios({
      method: "post",
      url: "https://insaid.co/xlri-backend/data.php",
      data: {
        type: "get_user_basic_details",
        user_id: localStorage.getItem("user_id"),
      },
    }).then(function (response) {
      localStorage.setItem("firstname", response.data.firstname);
      if(response.data.lastname.split(" ").length>1){
        localStorage.setItem("lastname", response.data.lastname.split(" ")[1]);
        localStorage.setItem("middlename", response.data.lastname.split(" ")[0]);
      }
      else{
        localStorage.setItem("lastname", response.data.lastname);
      }
      localStorage.setItem("mobile", response.data.mobile);
    });
  }
  useEffect(() => {
    userd();
  }, []);
  useEffect(() => {
    if (paymentid) {
      LoaderOpen();
      axios({
        method: "post",
        url: "https://insaid.co/xlri-backend/data.php",
        data: {
          type: "insert_application_details",
          user_id: parseInt(localStorage.getItem("user_id")),
          payment_id: paymentid,
          firstname: localStorage.getItem("firstname"),
          lastname: localStorage.getItem("lastname"),
          mobile: localStorage.getItem("mobile"),
          email: localStorage.getItem("email"),
          batch: batch[0].batch_id,
          program: course[0].id,
          amount: 1000000,
        },
      }).then((response) => {
        if (response.data.status == 200) {
          LoaderClose();
          props.handleNext2();
          axios({
            method: "post",
            url: "https://insaid.co/xlri-backend/data.php",
            data: {
              type: "update_step_two_status",
              user_id: parseInt(localStorage.getItem("user_id")),
              status: "complete",
            },
          }).then((response) => {
            if (response.data.status == 200) {
              props.stepCount();
              props.userd();
            }
          });
        } else {
          axios({
            method: "post",
            url: "https://insaid.co/xlri-backend/data.php",
            data: {
              type: "update_step_two_status",
              user_id: parseInt(localStorage.getItem("user_id")),
              status: "inprocess",
            },
          }).then((response) => {
            if (response.data.status == 200) {
              console.log("inprocess");
            }
          });
        }
      });
    }
  }, [paymentid]);
  console.log(course, "array");
  useEffect(() => {
    const fetchCourse = () => {
      axios({
        method: "post",
        url: "https://insaid.co/xlri-backend/data.php",
        data: {
          type: "fetch_xlri_programs",
        },
      }).then((response) => {
        // console.log(response.data[0].pname,"courseee")
        // setCourse([
        //   {
        //     id: response.data[0].pid,
        //     name: response.data[0].pname,
        //     pcode: response.data[0].pcode,
        //   },
        // ]);
        setCourse(response.data)
      });
    };
    console.log(course,"eee")
    const fetchBatch = () => {
      axios({
        method: "post",
        url: "https://insaid.co/xlri-backend/data.php",
        data: {
          type: "fetch_xlri_batches",
        },
      }).then((response) => {
        setBatch(response.data);
      });
    };
    fetchCourse();
    fetchBatch();
    props.userd();
  }, []);
  const handleChangecourse = (pcode, pid,cid) => {
    setCourses(pid);
    setCoursescode(pcode);
    setCategory(cid);

    console.log(pid);
  };
  const handleChangebatch = (registerId,batch,batchtext) => {
    setBatchs(batch);
    setBatchtxt(batchtext);
  //  setRegisterid(registerId)
  };
  // console.log(course[0].pcode,"check")
  const checkoutHandler = async (amount) => {
   
    const options = {
      key: "rzp_live_kuHNpOKPMVihkI",
      amount: amount * 100,
      currency: "INR",
      name: "Insaid",
      description: "registration fees for " + course[0].pcode,
      image:
        "https://www.insaid.co/wp-content/uploads/2021/05/insaid-text-logo-2x.png",
      // order_id: order.data.response.id,
      handler: function (response) {
        setPaymentid(response.razorpay_payment_id);
      },
      prefill: {
        name:
          localStorage.getItem("firstname") + localStorage.getItem("lastname"),
        email: localStorage.getItem("email"),
        contact: localStorage.getItem("mobile"),
      },
      notes: {
        address: "Razorpay Corporate Office",
      },
      theme: {
        color: "#121212",
      },
    };
    const razor = new window.Razorpay(options);
    razor.open();

    console.log("chala kya");
  };
  // console.log(window, "seee");
  return (
    <>
      {props.step.steptwo == "pending" ? (
        <Box>
          <Box sx={{display: { xs: "none", lg: "block"}}}>
          <Box
            sx={{
              mb: 0.5,
              
              p: 1,
              borderRadius: "5px",
            }}
            onClick={handleClickPersonal}
          >
            <Typography
              sx={{
                color: "#fff",
                fontWeight: "bold",
                textAlign: "center",
                fontSize: "23px",
              }}
            >
              Payment
            </Typography>
          </Box>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              mt: 1,
              mb: 1,
            }}
          >
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                First Name
              </Typography>
              <BootstrapInput
                sx={{ width: 480 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("firstname")}
              />
            </Box>
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Middle Name
              </Typography>
              <BootstrapInput
                sx={{ width: 480 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("middlename")}
              />
            </Box>
            
          </Box>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              mt: 1,
              mb: 1,
            }}
          >
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Last Name
              </Typography>
              <BootstrapInput
                sx={{ width: 480 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("lastname")}
              />
            </Box>
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Phone Number
              </Typography>
              <BootstrapInput
                type="number"
                sx={{ width: 480 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("mobile")}
              />
            </Box>
            
          </Box>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              mt: 1,
              mb: 1,
            }}
          >
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Email ID
              </Typography>
              <BootstrapInput
                type="email"
                sx={{ width: 480 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("email")}
              />
            </Box>
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Course Applying For
              </Typography>
              <FormControl fullWidth>
                <Select
                  size="small"
                  sx={{ width: 480, background: "#fff" }}
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={country}
                  defaultValue="38"
                  label="course"
                  // onChange={handleChangeCountry}
                >
                  
                  {course.map((val, i) => (
                    <MenuItem  onClick={() => handleChangecourse(val.pcode, val.pid,val.category_id)} value={val.pid}>{val.pname}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
            
          </Box>
          <Box 
          
          sx={{
            display: "flex",
            justifyContent: "space-between",
            mt: 1,
            mb: 1,
          }}
          >

          <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Application Fee
              </Typography>
              <BootstrapInput
                sx={{ width: 480 }}
                size="small"
                inputProps={{ readOnly: true }}
                defaultValue="INR10,000"
              />
            </Box>
            <Box sx={{ mb: 1 }}>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
            >
              Batch
            </Typography>
            <FormControl fullWidth>
              {/* <InputLabel id="demo-simple-select-label">Gender</InputLabel> */}
              <Select
                size="small"
                sx={{ width: 480, background: "#fff" }}
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                // value={country}
                defaultValue="2023-06-01"
                label="batch"
                // onChange={handleChangeCountry}
              >
                 {batch.map((val, i) => (
                      <MenuItem  onClick={() => handleChangebatch(val.register_id,val.batch_id,val.batch_text)} value={val.batch_id}>{val.batch_text}</MenuItem>
                    ))}
                {/* {batch.map((val, i) => (
                  <MenuItem value={val.id}>{val.name}</MenuItem>
                ))} */}
              </Select>
            </FormControl>
          </Box>
          </Box>
         

          <Box>
            <Typography
              sx={{
                fontWeight: "bold",
                fontSize: "14px",
                color: "#fff",
                mb: 1,
              }}
            >
              <i>Please make the payment below</i>
            </Typography>

            <Button
              variant="conatained"
              size="small"
              sx={{
                color: "#fff",
                mr: 2,
                background: "#fdb714",
                "&:hover": { background: "#fdb714", color: "#fff" },
              }}
              onClick={() => {
                checkoutHandler(10000);
              }}
            >
              Pay ₹10,000
            </Button>
          </Box>

          </Box>
          
      
         


          {/*  mobile version */}
          <Box sx={{ display: { xs: "block", lg: "none"}}}>
          <Box
            sx={{
              mb: 0.5,
             
              p: 1,
              borderRadius: "5px",
            }}
            onClick={handleClickPersonal}
          >
            <Typography
              sx={{
                color: "#fff",
                fontWeight: "bold",
                textAlign: "center",
                fontSize: "23px",
              }}
            >
              Payment
            </Typography>
          </Box>

          <Box
            sx={{
              // display: "flex",
              // justifyContent: "space-between",
              mt: 1,
              mb: 1,
            }}
          >
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                First Name
              </Typography>
              <BootstrapInput
                sx={{ width: 220 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("firstname")}
              />
            </Box>
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Middle Name
              </Typography>
              <BootstrapInput
                sx={{ width: 220 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("middlename")}
              />
            </Box>
            
          </Box>
          <Box
            sx={{
              // display: "flex",
              // justifyContent: "space-between",
              mt: 1,
              mb: 1,
            }}
          >
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Last Name
              </Typography>
              <BootstrapInput
                sx={{ width: 220 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("lastname")}
              />
            </Box>
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Phone Number
              </Typography>
              <BootstrapInput
                type="number"
                sx={{ width: 220 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("mobile")}
              />
            </Box>
            
          </Box>
          <Box
            sx={{
              // display: "flex",
              // justifyContent: "space-between",
              mt: 1,
              mb: 1,
            }}
          >
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Email ID
              </Typography>
              <BootstrapInput
                type="email"
                sx={{ width: 220 }}
                size="small"
                inputProps={{ readOnly: true }}
                value={localStorage.getItem("email")}
              />
            </Box>
            <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Course Applying For
              </Typography>
              <FormControl fullWidth>
                <Select
                  size="small"
                  sx={{ width: 220, background: "#fff" }}
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={country}
                  defaultValue="38"
                  label="course"
                  // onChange={handleChangeCountry}
                >
                  {course.map((val, i) => (
                    <MenuItem value={val.id}>{val.name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
           
          </Box>
          <Box 
          sx={{
            // display: "flex",
            // justifyContent: "space-between",
            mt: 1,
            mb: 1,
          }}
          >
          <Box>
              <Typography
                sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
              >
                Application Fee
              </Typography>
              <BootstrapInput
                sx={{ width: 220 }}
                size="small"
                inputProps={{ readOnly: true }}
                defaultValue="INR10,000"
              />
            </Box>
            <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#fff" }}
            >
              Batch
            </Typography>
            <FormControl fullWidth>
              {/* <InputLabel id="demo-simple-select-label">Gender</InputLabel> */}
              <Select
                size="small"
                sx={{ width: 220, background: "#fff" }}
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                // value={country}
                defaultValue="2023-06-01"
                label="batch"
                // onChange={handleChangeCountry}
              >
                {batch.map((val, i) => (
                  <MenuItem value={val.id}>{val.name}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>

          </Box>
          
          <Box>
            <Typography
              sx={{
                fontWeight: "bold",
                fontSize: "14px",
                color: "#fff",
                mb: 1,
              }}
            >
              <i>Please make the payment below</i>
            </Typography>

            <Button
              variant="conatained"
              size="small"
              sx={{
                color: "#fff",
                mr: 2,
                background: "#fdb714",
                "&:hover": { background: "#fdb714", color: "#fff" },
              }}
              onClick={() => {
                checkoutHandler(10000);
              }}
            >
              Pay ₹10,000
            </Button>
          </Box>
          </Box>
          
        </Box>
      ) : (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Box
            sx={{
              background: "#fff",
              borderRadius: "5px",
              border: "1px solid #fdb714",
              p: 3,
              width: 300,
            }}
          >
            <BorderLinearProgress
              variant="determinate"
              value={80}
              sx={{ mb: 2 }}
            />
            <Typography>
              Your payment is under process. Please contact your admission
              counsellor for further details
            </Typography>
          </Box>
        </Box>
      )}

      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={backopen}
      >
        <CircularProgress color="inherit" />
      </Backdrop>
    </>
  );
};
export default PaymentNew;
