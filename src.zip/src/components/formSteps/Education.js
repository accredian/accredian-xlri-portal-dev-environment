import React, { useEffect, useState } from "react";
import {
  Typography,
  Button,
  Box,
  Paper,
  Grid,
  TextField,
  FormControlLabel,
  Link,
  Badge,
  Checkbox,
  Tabs,
  Tab,
  Step,
} from "@mui/material";
import Collapse from "@mui/material/Collapse";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import { Country, State, City } from "country-state-city";
import axios from "axios";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";

const BootstrapInput = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#fcfcfb" : "#2b2b2b",
    border: "1px solid #ced4da",
    fontSize: 16,
    width: 480,
    height: 19,
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const Education = (props) => {
  const [openPersonal, setOpenPersonal] = useState(false);
  const [openADD, setOpenADD] = useState(false);
  const [openaddress, setOpenaddress] = useState(false);
  const [bachelorDegree, setBachelorDegree] = useState("");
  const [collegeName, setCollegename] = useState("");
  const [yearOfCompletion, setCompletionyear] = useState("");
  const [cgpa, setCgpa] = useState("");
  const [companyname, setCompanyName] = useState("");
  const [companyemail, setCompanyemail] = useState();
  const [previuosCompany, setPreviouscompany] = useState();
  const [bachelorDocuments, setBachelorDcument] = useState("");
  const [experienceDocuments, setexperienceDcument] = useState("");
  const [nxt, setNxt] = useState(true);
  const [choice, setChoice] = useState("");
  const [backopen, setBackopen] = useState(false);
  const LoaderClose = () => {
    setBackopen(false);
  };
  const LoaderOpen = () => {
    setBackopen(true);
  };

  const handleChangeChoice = (event) => {
    setChoice(event.target.value);
  };
  const handleChangeDegree = (event) => {
    setBachelorDegree(event.target.value);
  };
  const handleChangeCollegeName = (event) => {
    setCollegename(event.target.value);
  };
  const handleChangeYear = (event) => {
    setCompletionyear(event.target.value);
  };
  const handleChangeCgpa = (event) => {
    setCgpa(event.target.value);
  };
  const handleChangeCpmanyName = (event) => {
    setCompanyName(event.target.value);
  };
  const handleChangeCompanyemail = (event) => {
    setCompanyemail(event.target.value);
  };
  const handleChangePreviousCompany = (event) => {
    setPreviouscompany(event.target.value);
  };
  const handleChangeBachelorDocuments = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && selectedFile.size <= 5000000) {
      setBachelorDcument(selectedFile);
    } else {
      setBachelorDcument(null);
      alert("Please select a file of size not more than 5MB");
    }
    // setBachelorDcument(event.target.files[0]);
  };
  const handleChangeExperinceDocuments = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && selectedFile.size <= 5000000) {
      setexperienceDcument(selectedFile);
    } else {
      setexperienceDcument(null);
      alert("Please select a file of size not more than 5MB");
    }
    // setexperienceDcument(event.target.files[0]);
  };

  const handleClickPersonal = () => {
    setOpenPersonal(!openPersonal);
  };
  const handleClickAdd = () => {
    setOpenADD(!openADD);
  };
  const handleClickaddress = () => {
    setOpenaddress(!openaddress);
  };

  console.log(
    bachelorDegree,
    collegeName,
    yearOfCompletion,
    cgpa,
    companyname,
    companyemail,
    previuosCompany,
    bachelorDocuments,
    experienceDocuments
  );
  // if(props){
  useEffect(() => {
    if (
      bachelorDegree &&
        collegeName &&
        yearOfCompletion &&
        cgpa &&
        bachelorDocuments &&
        (companyemail &&
        companyname) ||
      (previuosCompany && experienceDocuments)
    ) {
      setNxt(false);
    }
  }, [
    bachelorDegree,
    collegeName,
    yearOfCompletion,
    cgpa,
    companyname,
    companyemail,
    previuosCompany,
    bachelorDocuments,
    experienceDocuments,
  ]);

  // }

  const handleNext = () => {
    LoaderOpen();
    if (
      bachelorDegree &&
      collegeName &&
      yearOfCompletion &&
      cgpa &&
      bachelorDocuments
    ) {
      var formData = new FormData();
      formData.append("file", bachelorDocuments);
      formData.append("type", "insert_education_details");
      formData.append("degree", bachelorDegree);
      formData.append("college_name", collegeName);
      formData.append("completion_year", yearOfCompletion);
      formData.append("cgpa", cgpa);
      formData.append("user_id", parseInt(localStorage.getItem("user_id")));

      axios({
        method: "post",
        url: "https://insaid.co/xlri-backend/file-upload.php",
        headers: { "Content-Type": "multipart/form-data" },
        data: formData,
      }).then(function (response) {
        if (response.data.status == 200) {
          if (companyname) {
            if (companyname && companyemail) {
              axios({
                method: "post",
                url: "https://insaid.co/xlri-backend/data.php",
                data: {
                  type: "insert_work_details",
                  user_id: parseInt(localStorage.getItem("user_id")),
                  company_name: companyname,
                  company_email: companyemail,
                  working: "yes",
                },
              }).then((response) => {
                if (response.data.status == 200) {
                  const options = {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                      "Content-Type": "application/json",
                    },
                  };
                  const sendData = {
                    user_id: localStorage.getItem("user_id"),
                  };

                  axios({
                    method: "post",
                    url: "https://insaid.co/generate-xlri-applications.php",
                    data: {
                      user_id: localStorage.getItem("user_id"),
                    },

                    // options
                  })
                    // axios
                    // .post(
                    //   "https://insaid.co/generate-xlri-applications.php",
                    //   sendData,
                    //   options
                    // )
                    .then((response) => {
                      if (response.data.status == 200) {
                        LoaderClose();
                        axios({
                          method: "post",
                          url: "https://insaid.co/xlri-backend/data.php",
                          data: {
                            type: "update_step_four_status",
                            user_id: parseInt(localStorage.getItem("user_id")),
                            status: "complete",
                          },
                        }).then((response) => {
                          if (response.data.status == 200) {
                            props.stepCount();
                            props.userd();
                          }
                        });
                      }
                    });
                }
              });
            }
          } else if (previuosCompany && experienceDocuments) {
            const formData = new FormData();
            formData.append("file", experienceDocuments);
            formData.append("working", "no");
            formData.append("type", 'insert_work_details');
            formData.append("previous_company", previuosCompany);
            formData.append(
              "user_id",
              parseInt(localStorage.getItem("user_id"))
            );
            axios({
              method: "post",
              url: "https://insaid.co/xlri-backend/file-upload.php",
              headers: { "Content-Type": "multipart/form-data" },
              data: 
                // type: "insert_work_details",
                formData,
              
            }).then((response) => {
              props.handleNext4();
              if (response.data.status == 200) {
                
                const options = {
                  headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Content-Type": "application/json",
                  },
                };
                const sendData = {
                  user_id: localStorage.getItem("user_id"),
                };
                axios({
                  method: "post",
                  url: "https://insaid.co/generate-xlri-applications.php",
                  data: {
                    user_id: localStorage.getItem("user_id"),
                  },

                  // options
                }).then((response) => {
                  if (response.data.status == 200) {
                    LoaderClose();
                    axios({
                      method: "post",
                      url: "https://insaid.co/xlri-backend/data.php",
                      data: {
                        type: "update_step_four_status",
                        user_id: parseInt(localStorage.getItem("user_id")),
                        status: "complete",
                      },
                    }).then((response) => {
                      if (response.data.status == 200) {
                        props.stepCount();
                        props.userd();
                      }
                    });
                  }
                });
              }
            });
          }
        }
      });
    }
  };

  //  boxShadow: "0 0 1rem 0 rgba(0, 0, 0, .2)",
  //  // border-radius: 5px;
  //  backgroundColor: "rgba(255, 255, 255, .15)",
  return (
    <>
      <Box sx={{display: { xs: "none", lg: "block"}}}>
        <Box
          sx={{ mb: 1, p: 1, borderRadius: "5px" }}
          onClick={handleClickPersonal}
        >
          {/* {openPersonal ? <ExpandLess sx={{color:"#fff"}} /> : <ExpandMore sx={{color:"#fff"}} />} */}
          <Typography
            sx={{
              color: "#fff",
              fontWeight: "bold",
              textAlign: "center",
              fontSize: "23px",
            }}
          >
            Education Details
          </Typography>
        </Box>
        
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            mt: 1,
            mb: 1,
          }}
        >
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              Bachelor's Degree Name<span style={{ color: "red" }}>*</span>
            </Typography>
            <FormControl fullWidth>
              {/* <InputLabel id="demo-simple-select-label">Payment Type</InputLabel> */}
              <Select
                size="small"
                sx={{ width: 480, background: "#fff" }}
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                //  value={bachelorDegree}
                onChange={handleChangeDegree}
                defaultValue={"select"}
              >
                <MenuItem disabled="true" value={"select"}>
                  Select your degree
                </MenuItem>
                <MenuItem value={"B.Tech"}>B.Tech</MenuItem>
                <MenuItem value={"B.Voc"}>B.Voc</MenuItem>
                <MenuItem value={"B.Sc"}>B.Sc</MenuItem>
                <MenuItem value={"B.S"}>B.S</MenuItem>
                <MenuItem value={"BPharm"}>BPharm</MenuItem>
                <MenuItem value={"B.com"}>B.com</MenuItem>
                <MenuItem value={"BBA"}>BBA</MenuItem>
                <MenuItem value={"BBA Honors"}>BBA Honors</MenuItem>
                <MenuItem value={"BCA"}>BCA</MenuItem>
                <MenuItem value={"BArch"}>BArch</MenuItem>
                <MenuItem value={"B.L.L.A.B"}>B.L.L.A.B</MenuItem>
                {/* <MenuItem value={30}>Others</MenuItem> */}
              </Select>
            </FormControl>
            {/* {name?"":<Typography sx={{color:"red"}}>This Filed is Required</Typography>} */}
          </Box>
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              College/University Name <span style={{ color: "red" }}>*</span>
            </Typography>
            <BootstrapInput
              onChange={handleChangeCollegeName}
              value={collegeName}
              sx={{ width: 480 }}
              size="small"
              //  onKeyPress={(e) => {
              //     if (new RegExp(/[a-zA-Z]/).test(e.key)) {
              //     } else e.preventDefault();
              //   }}
            />
            {/* {name?"":<Typography sx={{color:"red"}}>This Filed is Required</Typography>} */}
          </Box>
        </Box>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            mt: 1,
            mb: 1,
          }}
        >
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              Year of Completion<span style={{ color: "red" }}>*</span>
            </Typography>
            <BootstrapInput
              type="number"
              sx={{ width: 480 }}
              size="small"
              onChange={handleChangeYear}
              value={yearOfCompletion}
            />
          </Box>
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              Bachelors Degree % / CGPA<span style={{ color: "red" }}>*</span>
            </Typography>
            <BootstrapInput
              type="number"
              sx={{ width: 480 }}
              size="small"
              onChange={handleChangeCgpa}
              value={cgpa}
            />
          </Box>
        </Box>

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            mt: 1,
            mb: 1,
          }}
        >
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              Upload Relevant Document<span style={{ color: "red" }}>*</span>
            </Typography>
            <TextField
              inputProps={{
                accept: "application/pdf, image/*",
                // onChange: handleFileChange,
              }}
              onChange={handleChangeBachelorDocuments}
              size="small"
              sx={{ width: 480, background: "#fff", borderRadius: "4px" }}
              fullWidth
              type="file"
            ></TextField>
          </Box>
        </Box>

        <Box
          sx={{ mb: 0.5, p: 1, borderRadius: "5px" }}
          onClick={handleClickaddress}
        >
          {/* {openaddress ? <ExpandLess sx={{color:"#fff"}} /> : <ExpandMore sx={{color:"#fff"}} />} */}
          <Typography
            sx={{
              color: "#fff",
              fontWeight: "bold",
              textAlign: "center",
              fontSize: "23px",
            }}
          >
            Work Experience Details
          </Typography>
        </Box>
        {/* <Collapse in={openaddress} timeout="auto" unmountOnExit sx={{mb:2}}> */}
        <Box>
          <Typography
            sx={{
              fontWeight: "bold",
              fontSize: "14px",
              color: "#fff",
              mt: 2,
              mb: 1,
              width: 150,
            }}
          >
            Are you currently working?
          </Typography>
          <FormControl fullWidth>
            {/* <InputLabel id="demo-simple-select-label">Payment Type</InputLabel> */}
            <Select
              size="small"
              sx={{ width: 480, background: "#fff", mt: 1 }}
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={choice}
              onChange={handleChangeChoice}
              defaultValue={"select"}
            >
              <MenuItem disabled="true" value={"select"}>
                select
              </MenuItem>
              <MenuItem value={"Yes"}>Yes</MenuItem>
              <MenuItem value={"No"}>No</MenuItem>
              {/* <MenuItem value={30}>Others</MenuItem> */}
            </Select>
          </FormControl>
        </Box>
        {choice == "" ? (
          <Box></Box>
        ) : (
          <Box>
            {choice == "Yes" ? (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  mt: 1,
                  mb: 1,
                }}
              >
                <Box>
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      fontSize: "14px",
                      color: "#ffffff",
                    }}
                  >
                    Current Company Name <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <BootstrapInput
                    onChange={handleChangeCpmanyName}
                    value={companyname}
                    sx={{ width: 480 }}
                    size="small"
                    onKeyPress={(e) => {
                      if (new RegExp(/[a-zA-Z]/).test(e.key)) {
                      } else e.preventDefault();
                    }}
                  />
                </Box>
                <Box>
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      fontSize: "14px",
                      color: "#ffffff",
                    }}
                  >
                    Company Email Id <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <TextField
                    type="email"
                    onChange={handleChangeCompanyemail}
                    value={companyemail}
                    sx={{ width: 480, background: "#fff", borderRadius: "5px" }}
                    size="small"
                  />
                </Box>
              </Box>
            ) : (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  mt: 1,
                  mb: 1,
                }}
              >
                <Box>
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      fontSize: "14px",
                      color: "#ffffff",
                    }}
                  >
                    {" "}
                    Previous Company Name{" "}
                    <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <BootstrapInput
                    onChange={handleChangePreviousCompany}
                    value={previuosCompany}
                    sx={{ width: 480 }}
                    size="small"
                    onKeyPress={(e) => {
                      if (new RegExp(/[a-zA-Z]/).test(e.key)) {
                      } else e.preventDefault();
                    }}
                  />
                </Box>
                <Box>
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      fontSize: "14px",
                      color: "#ffffff",
                    }}
                  >
                    Upload Relevant Document
                    <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <TextField
                    inputProps={{
                      accept: "application/pdf, image/*",
                      // onChange: handleFileChange,
                    }}
                    onChange={handleChangeExperinceDocuments}
                    size="small"
                    sx={{ width: 480, background: "#fff", borderRadius: "4px" }}
                    fullWidth
                    type="file"
                  ></TextField>
                </Box>
              </Box>
            )}
          </Box>
        )}

        {/* </Collapse> */}
        <Box sx={{ display: "flex", justifyContent: "end", mt: 1 }}>
          <Button
            variant="conatained"
            size="small"
            sx={{
              color: "#fff",
              background: "#fdb714",
              "&:hover": { background: "#fdb714", color: "#fff" },
            }}
            onClick={handleNext}
            disabled={nxt}
          >
            Submit
          </Button>
        </Box>
      </Box>

      {/* mobile version */}
      <Box sx={{display: { xs: "block", lg: "none"}}}>
        <Box
          sx={{ mb: 1, p: 1, borderRadius: "5px" }}
          onClick={handleClickPersonal}
        >
          {/* {openPersonal ? <ExpandLess sx={{color:"#fff"}} /> : <ExpandMore sx={{color:"#fff"}} />} */}
          <Typography
            sx={{
              color: "#fff",
              fontWeight: "bold",
              textAlign: "center",
              fontSize: "20px",
            }}
          >
            Education Details
          </Typography>
        </Box>
        
        <Box
          sx={{
            // display: "flex",
            // justifyContent: "space-between",
            mt: 1,
            mb: 1,
          }}
        >
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              Bachelor's Degree Name<span style={{ color: "red" }}>*</span>
            </Typography>
            <FormControl fullWidth>
              {/* <InputLabel id="demo-simple-select-label">Payment Type</InputLabel> */}
              <Select
                size="small"
                sx={{ width: 220, background: "#fff" }}
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                //  value={bachelorDegree}
                onChange={handleChangeDegree}
                defaultValue={"select"}
              >
                <MenuItem disabled="true" value={"select"}>
                  Select your degree
                </MenuItem>
                <MenuItem value={"B.Tech"}>B.Tech</MenuItem>
                <MenuItem value={"B.Voc"}>B.Voc</MenuItem>
                <MenuItem value={"B.Sc"}>B.Sc</MenuItem>
                <MenuItem value={"B.S"}>B.S</MenuItem>
                <MenuItem value={"BPharm"}>BPharm</MenuItem>
                <MenuItem value={"B.com"}>B.com</MenuItem>
                <MenuItem value={"BBA"}>BBA</MenuItem>
                <MenuItem value={"BBA Honors"}>BBA Honors</MenuItem>
                <MenuItem value={"BCA"}>BCA</MenuItem>
                <MenuItem value={"BArch"}>BArch</MenuItem>
                <MenuItem value={"B.L.L.A.B"}>B.L.L.A.B</MenuItem>
                {/* <MenuItem value={30}>Others</MenuItem> */}
              </Select>
            </FormControl>
            {/* {name?"":<Typography sx={{color:"red"}}>This Filed is Required</Typography>} */}
          </Box>
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              College/University Name <span style={{ color: "red" }}>*</span>
            </Typography>
            <BootstrapInput
              onChange={handleChangeCollegeName}
              value={collegeName}
              sx={{ width: 220 }}
              size="small"
              //  onKeyPress={(e) => {
              //     if (new RegExp(/[a-zA-Z]/).test(e.key)) {
              //     } else e.preventDefault();
              //   }}
            />
            {/* {name?"":<Typography sx={{color:"red"}}>This Filed is Required</Typography>} */}
          </Box>
        </Box>
        <Box
          sx={{
            // display: "flex",
            // justifyContent: "space-between",
            mt: 1,
            mb: 1,
          }}
        >
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              Year of Completion<span style={{ color: "red" }}>*</span>
            </Typography>
            <BootstrapInput
              type="number"
              sx={{ width: 220 }}
              size="small"
              onChange={handleChangeYear}
              value={yearOfCompletion}
            />
          </Box>
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              Bachelors Degree % / CGPA<span style={{ color: "red" }}>*</span>
            </Typography>
            <BootstrapInput
              type="number"
              sx={{ width: 220 }}
              size="small"
              onChange={handleChangeCgpa}
              value={cgpa}
            />
          </Box>
        </Box>

        <Box
          sx={{
            // display: "flex",
            // justifyContent: "space-between",
            mt: 1,
            mb: 1,
          }}
        >
          <Box>
            <Typography
              sx={{ fontWeight: "bold", fontSize: "14px", color: "#ffffff" }}
            >
              Upload Relevant Document<span style={{ color: "red" }}>*</span>
            </Typography>
            <TextField
              inputProps={{
                accept: "application/pdf, image/*",
                // onChange: handleFileChange,
              }}
              onChange={handleChangeBachelorDocuments}
              size="small"
              sx={{ width: 220, background: "#fff", borderRadius: "4px" }}
              fullWidth
              type="file"
            ></TextField>
          </Box>
        </Box>

        <Box
          sx={{ mb: 0.5, p: 1, borderRadius: "5px" }}
          onClick={handleClickaddress}
        >
          {/* {openaddress ? <ExpandLess sx={{color:"#fff"}} /> : <ExpandMore sx={{color:"#fff"}} />} */}
          <Typography
            sx={{
              color: "#fff",
              fontWeight: "bold",
              textAlign: "center",
              fontSize: "20px",
            }}
          >
            Work Experience Details
          </Typography>
        </Box>
        {/* <Collapse in={openaddress} timeout="auto" unmountOnExit sx={{mb:2}}> */}
        <Box>
          <Typography
            sx={{
              fontWeight: "bold",
              fontSize: "14px",
              color: "#fff",
              mt: 2,
              mb: 1,
              width: 150,
            }}
          >
            Are you currently working?
          </Typography>
          <FormControl fullWidth>
            {/* <InputLabel id="demo-simple-select-label">Payment Type</InputLabel> */}
            <Select
              size="small"
              sx={{ width: 220, background: "#fff", mt: 1 }}
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={choice}
              onChange={handleChangeChoice}
              defaultValue={"select"}
            >
              <MenuItem disabled="true" value={"select"}>
                select
              </MenuItem>
              <MenuItem value={"Yes"}>Yes</MenuItem>
              <MenuItem value={"No"}>No</MenuItem>
              {/* <MenuItem value={30}>Others</MenuItem> */}
            </Select>
          </FormControl>
        </Box>
        {choice == "" ? (
          <Box></Box>
        ) : (
          <Box>
            {choice == "Yes" ? (
              <Box
                sx={{
                  // display: "flex",
                  // justifyContent: "space-between",
                  mt: 1,
                  mb: 1,
                }}
              >
                <Box>
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      fontSize: "14px",
                      color: "#ffffff",
                    }}
                  >
                    Current Company Name <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <BootstrapInput
                    onChange={handleChangeCpmanyName}
                    value={companyname}
                    sx={{ width: 220 }}
                    size="small"
                    onKeyPress={(e) => {
                      if (new RegExp(/[a-zA-Z]/).test(e.key)) {
                      } else e.preventDefault();
                    }}
                  />
                </Box>
                <Box>
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      fontSize: "14px",
                      color: "#ffffff",
                    }}
                  >
                    Company Email Id <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <TextField
                    type="email"
                    onChange={handleChangeCompanyemail}
                    value={companyemail}
                    sx={{ width: 220, background: "#fff", borderRadius: "5px" }}
                    size="small"
                  />
                </Box>
              </Box>
            ) : (
              <Box
                sx={{
                  // display: "flex",
                  // justifyContent: "space-between",
                  mt: 1,
                  mb: 1,
                }}
              >
                <Box>
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      fontSize: "14px",
                      color: "#ffffff",
                    }}
                  >
                    {" "}
                    Previous Company Name{" "}
                    <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <BootstrapInput
                    onChange={handleChangePreviousCompany}
                    value={previuosCompany}
                    sx={{ width: 220 }}
                    size="small"
                    onKeyPress={(e) => {
                      if (new RegExp(/[a-zA-Z]/).test(e.key)) {
                      } else e.preventDefault();
                    }}
                  />
                </Box>
                <Box>
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      fontSize: "14px",
                      color: "#ffffff",
                    }}
                  >
                    Upload Relevant Document
                    <span style={{ color: "red" }}>*</span>
                  </Typography>
                  <TextField
                    inputProps={{
                      accept: "application/pdf, image/*",
                      // onChange: handleFileChange,
                    }}
                    onChange={handleChangeExperinceDocuments}
                    size="small"
                    sx={{ width: 220, background: "#fff", borderRadius: "4px" }}
                    fullWidth
                    type="file"
                  ></TextField>
                </Box>
              </Box>
            )}
          </Box>
        )}

        {/* </Collapse> */}
        <Box sx={{ display: "flex", justifyContent: "end", mt: 1 }}>
          <Button
            variant="conatained"
            size="small"
            sx={{
              color: "#fff",
              background: "#fdb714",
              "&:hover": { background: "#fdb714", color: "#fff" },
            }}
            onClick={handleNext}
            disabled={nxt}
          >
            Submit
          </Button>
        </Box>
      </Box>
      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={backopen}
      >
        <Box sx={{ display: "flex" }}>
          <CircularProgress color="inherit" />
          <Typography sx={{ ml: 2 }}>
            Processing your application form
          </Typography>
        </Box>
      </Backdrop>
    </>
  );
};
export default Education;
